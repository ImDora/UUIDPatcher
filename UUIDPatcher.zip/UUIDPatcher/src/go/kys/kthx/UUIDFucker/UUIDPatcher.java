package go.kys.kthx.UUIDFucker;

import go.kys.kthx.UUIDFucker.Listeners.JoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class UUIDPatcher extends JavaPlugin {
    public static int port = 0000;
    public static String message = "well done u fucked up the config!";
    public static UUIDPatcher instance;
    @Override
    public void onEnable() {
        instance = this;
        getServer().getPluginManager().registerEvents(new JoinEvent(),this);
        getConfig().options().copyDefaults(true);
        saveConfig();
        loadConfig();
        new PacketManager().inject();
    }

    private void loadConfig() {
        port = getConfig().getInt("Port");
        message = getConfig().getString("Message").replace("&","§");
    }
}
