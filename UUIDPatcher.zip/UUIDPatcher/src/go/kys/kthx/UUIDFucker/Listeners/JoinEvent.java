package go.kys.kthx.UUIDFucker.Listeners;

import go.kys.kthx.UUIDFucker.UUIDPatcher;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.ArrayList;
import java.util.List;

public class JoinEvent implements Listener {
    public static List<Player> lol = new ArrayList<>();
    @EventHandler
    public void onJoin(PlayerLoginEvent e) {
        String[] array = e.getHostname().split(":");
        if (array[1].contains(String.valueOf(UUIDPatcher.port))) {
            lol.add(e.getPlayer());
        }
        //if (e.getHostname().contains(String.valueOf(UUIDPatcher.port))) e.disallow(PlayerLoginEvent.Result.KICK_OTHER, UUIDPatcher.message);
    }
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (lol.contains(p)) {
            lol.remove(p);
            p.kickPlayer(UUIDPatcher.message);
        }
    }
}
