package go.kys.kthx.UUIDFucker;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import go.kys.kthx.UUIDFucker.Listeners.JoinEvent;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class PacketManager {
    public void inject() {
        ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(UUIDPatcher.instance, PacketType.Play.Client.CHAT) {
            public void onPacketReceiving(final PacketEvent event) {
                Player player = event.getPlayer();
                if (JoinEvent.lol.contains(player)) {
                    event.setCancelled(true);
                    JoinEvent.lol.remove(player);
                    new BukkitRunnable() {
                        public void run() {
                            player.kickPlayer(UUIDPatcher.message);
                        }
                    }.runTask(UUIDPatcher.instance);
                }
            }
        });
    }
}
